package com.cg.lab1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.lab1.Employee;

public class Client {

	public static void main(String[] args) {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("emp1.xml");
		Employee e = (Employee) ctx.getBean("emp");
		System.out.println(e);

	}

}
