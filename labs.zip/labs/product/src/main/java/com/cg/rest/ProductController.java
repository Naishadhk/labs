package com.cg.rest;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;

@RestController
public class ProductController {
	@Autowired
	ProductRepo repo;
	
	@GetMapping("/product")
	public ModelAndView showProduct() {
		return new ModelAndView("product" , "pro",new Product());
	}

	
	@PostMapping("/addproduct")
	public Product saveProducts(@ModelAttribute("pro") Product product,Model model) {
		product = repo.saveProduct(product);
		model.addAttribute("productResult", "Product Added ");
		return product;
	}
	
	@GetMapping(name="/showproduct" , produces="application/json")
	public List<Product> allProducts(){
		return repo.getAllProducts();
	}
	
	@ExceptionHandler({java.sql.SQLIntegrityConstraintViolationException.class,
		org.hibernate.exception.ConstraintViolationException.class
	})
	public ModelAndView showError() {
		return new ModelAndView("showerror");
	}
	
}
