package com.cg.service;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.cg.entity.Trainee;
import com.cg.repo.TraineeRepo;

@Service
@Transactional
public class TraineeServiceImpl implements TraineeService {

	@Autowired
	TraineeRepo repo;
	

	

	public Trainee getTraineeById(int id)  throws NoSuchElementException {

		try {
			return repo.findById(id).get();
		} catch (NoSuchElementException e) {
			throw new NoSuchElementException("No Trainee found for this id :" +id);
		}
	}

	public Iterable<Trainee> getAllTrainee() {
		
		return repo.findAll();
	}

	public Trainee saveTrainee(Trainee t) {
		
		return repo.save(t);
	}

	public String deleteTrainee(int id) {
		Trainee t = repo.findById(id).get();
		repo.delete(t);
		return "Trainee Deleted";
	}

	public Trainee modifyTrainee(Trainee t,int id) {
		t.setTraineeId(id);
		repo.save(t);
		return t;
	
	}

}
