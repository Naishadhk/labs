package com.cg.lab4;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("emp4.xml");
		Employee emp = (Employee) ctx.getBean("list");
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Employee ID");
		int id = sc.nextInt();

		for (Employee emp1 : emp.getEmpList())
			if (id == emp1.getEmployeeId())
				System.out.println(emp1);

		
	}

}
