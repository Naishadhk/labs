package com.cg.service;

import com.cg.entity.Trainee;

public interface TraineeService {

	Trainee saveTrainee(Trainee t);

	String deleteTrainee(int id);

	Trainee modifyTrainee(Trainee t,int id);

	Trainee getTraineeById(int id);

	Iterable<Trainee> getAllTrainee();
}
