package com.cg.lab2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("emp2.xml");
		Employee e = ctx.getBean(Employee.class);
		System.out.println(e);
	}

}
